const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended : false}));
app.use(bodyParser.json());

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: ' ',
    database: 'perikanan'
});

connection.connect((err)=>{
    if (err) {
        console.error("terjadi kesalahan dlm koneksi ke mysql:", err.stack);
        return;
    }
    console.log("koneksi mysql berhasil dengan id" +connection.threadId)
});

app.set('view engine', 'ejs');

//session
// Login
app.post('/', (req, res) => {
    const { username, password } = req.body;
    if (username === 'admin' && password === '12345') {
        req.session.user = { username };
        res.send('login berhasil');
    } else {
        res.status(401).send('login gagal');
    }
});

// Logout
app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send('Gagal keluar. Silakan coba lagi.');
        }
        res.send('Anda telah berhasil keluar.');
    });
});

//routing CRUD nelayan
//read
app.get('/nelayan', (req, re)=>{
    const query = 'SELECT * FROM nelayan';
    connection.query (query, (err, results)=> {
        res.render('nelayan', {petugas: results});
    });
});

//create
app.post('/nelayan', (req, res)=>{
    const { nama_nelayan} = req.body;
    const query = 'INSERT INTO nelayan (nama_nelayan) VALUES (?)';
    connection.query(query, [nama_nelayan], (err, result)=>{
        if(err) throw err;
        res.redirect('/nelayan');
    });
});

//update
app.get('/edit/:id', (req,res)=>{
    const query= 'select * from nelayan where id = ?';
    connection.query (query, [req.params.id], (err, result)=>{
        if(err) throw err;
        res.render('edit', {nelayan: result[0]});
    });
});

app.post('/edit/:id', (req, res)=> {
    const { nama_nelayan } = req.body;
    const query = 'update nelayan set nama_nelayan = ?';
    connection.query (query, [nama_nelayan, req.params.id], (err, result)=>{
        if(err) throw err;
        res.redirect('/nelayan');
    });
});

//delete
app.get('/delete/:id', (req, res) => {
    const { id } = req.params; 
    const query = 'DELETE FROM nelayan WHERE id = ?';
    connection.query(query, [id], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Terjadi kesalahan saat menghapus data nelayan.');
        }
        if (result.affectedRows === 0) {
            return res.status(404).send('nelayan tidak ditemukan.');
        }
        res.status(200).send('nelayan berhasil dihapus.');
    });
});

//routing CRUD hasil_tangkapan
//read
app.get('/hasil_tangkapan', (req, re)=>{
    const query = 'SELECT * FROM hasil_tangkapan';
    connection.query (query, (err, results)=> {
        res.render('hasil_tangkapan', {petugas: results});
    });
});

//create
app.post('/hasil_tangkapan', (req, res)=>{
    const {jumlah, jenis_tangkapan} = req.body;
    const query = 'INSERT INTO hasil_tangkapan (jumlah, jenis_tangkapan) VALUES (?,?)';
    connection.query(query, [jumlah, jenis_tangkapan], (err, result)=>{
        if(err) throw err;
        res.redirect('/hasil_tangkapan');
    });
});

//update
app.get('/edit/:id', (req,res)=>{
    const query= 'select * from hasil_tangkapan where id = ?';
    connection.query (query, [req.params.id], (err, result)=>{
        if(err) throw err;
        res.render('edit', {hasil_tangkapan: result[0]});
    });
});

app.post('/edit/:id', (req, res)=> {
    const { jumlah, jenis_tangkapan } = req.body;
    const query = 'update hasil_tangkapan set jumlah, jenis_tangkapan = ?,?';
    connection.query (query, [jumlah, jenis_tangkapan, req.params.id], (err, result)=>{
        if(err) throw err;
        res.redirect('/hasil_tangkapan');
    });
});

//delete
app.get('/delete/:id', (req, res) => {
    const { id } = req.params; 
    const query = 'DELETE FROM hasil_tangkapan WHERE id = ?';
    connection.query(query, [id], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Terjadi kesalahan saat menghapus data hasil_tangkapan.');
        }
        if (result.affectedRows === 0) {
            return res.status(404).send('hasil_tangkapan tidak ditemukan.');
        }
        res.status(200).send('hasil_tangkapan berhasil dihapus.');
    });
});


app.listen(3000,() => {
    console.log("server berjalan di port 3000, buka web melalui http://localhost:3000")
});
